
public class LukaSyntaxException extends IllegalArgumentException {

    private static final long serialVersionUID = 1L;

    public LukaSyntaxException() {
        super();
    }

    public LukaSyntaxException(String message) {
        super(message);
    }

}
